document.addEventListener('DOMContentLoaded', function () {
  const latestLink = document.getElementById('latestLink');
  const copyBtn = document.getElementById('copyBtn');
  const status = document.getElementById('copyStatus');

  copyBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      await navigator.clipboard.writeText(latestLink.href);
      const icon = copyBtn.querySelector('.material-symbols-outlined');
      const text = copyBtn.querySelector('.btn-text');
      const prevIcon = icon.textContent;
      const prevText = text.textContent;

      icon.textContent = 'check';
      text.textContent = 'Copied!';
      status.textContent = 'URL copied to clipboard';

      setTimeout(() => {
        icon.textContent = prevIcon;
        text.textContent = prevText;
        status.textContent = '';
      }, 1200);
    } catch (err) {
      status.textContent = 'Copy failed';
    }
  });
});
